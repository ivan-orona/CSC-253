﻿/**
* September 29, 2018
* CSC 253
* Miguel Ivan Orona
* This program will allow prompt the user to enter a name and the program will read
* 2 name files, place them into a list, and search through the list for a matching name.
* If the name is present, the program will display a confirmation text, but
* will display a try again message if the name is not present.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW3_Orona
{
    public partial class Form1 : Form
    {
        //New list to hold the names for the "BoyNames.txt" file.
        List<string> namesList = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }
        private void ReadNames()    //Will Read the "BoyNames.txt" & "GirlNames.txt" file.
        {
            try
            {
                
                StreamReader inputFileBoys = File.OpenText("BoyNames.txt"); //Opens the file.
                string holder;  //Holds the read lines.

                while (!inputFileBoys.EndOfStream)
                {
                    holder = inputFileBoys.ReadLine();  //Places the lines read into a variable
                    namesList.Add(holder);  //Adds the variable to the namesList.
                }
                inputFileBoys.Close();  //Close the boys file.  

                foreach (string x in namesList) //This will add each line to the list until there are no more lines to be read.
                {
                    outputListBox.Items.Add(x); //Displays the named items in a listbox.
                }

                StreamReader inputFileGirls = File.OpenText("GirlNames.txt");   //Opens the file.
                string holder2; //Holds the read lines.

                while (!inputFileGirls.EndOfStream)
                {
                    holder2 = inputFileGirls.ReadLine();    //Places the lines read into a variable.
                    namesList.Add(holder2);    //Adds the variable to the namesList.
                }
                inputFileGirls.Close(); //Closes the girls name.
                foreach (string i in namesList) //This will add each line to the list until there are no more lines to be read.
                {
                    outputListBox.Items.Add(i); //Displays the named items in a listbox.
                }
            }
            catch
            {
                MessageBox.Show("An error has occurred!");   //Displays an error.
            }
        }
        private void CheckNames()
        {
            string userInput = inputTextBox.Text; //Places the user input into a variable.

            for (int i = 0; i < namesList.Count; i++) 
            {
                if (namesList[i]==userInput) //Checks to see if user input is matched to a name in the list.
                {
                    outputTextBox.Text = (userInput + " is in the popular names list."); //Displays the matching name if present.
                    break;  //Breaks the loop and prevents from infinitely going.
                }
                else
                {
                    outputTextBox.Text = (userInput + " is not in the popular names list."); //If names don't match, it will output.
                }
            }
        }
      
        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Calls.
            ReadNames();
            CheckNames();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears the boxes.
            inputTextBox.Clear();
            outputListBox.Items.Clear();
            outputTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program.
            this.Close();
        }
    }
}
//End of program.