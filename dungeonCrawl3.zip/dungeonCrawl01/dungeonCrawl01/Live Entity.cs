﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class Live_Entity
    {
        public string _Name { get; set; }
        public int _HP { get; set; }
        public int _Damage { get; set; }

        public Boolean _Alive = true;

        public Live_Entity(string name, int hp, int damage, bool alive)
        {
            _Name = name;
            _HP = hp;
            _Damage = damage;
            _Alive = alive;
        }
    }
}
