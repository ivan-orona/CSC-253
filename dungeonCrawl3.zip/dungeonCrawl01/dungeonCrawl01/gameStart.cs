﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    class gameStart
    {
        public static void newGame()
        {
            string newgameChoice;
            
            
            
            commonMessages.newGamePrompt();
            newgameChoice = Console.ReadLine().ToLower();

            if (newgameChoice == "n")
            {
                Console.WriteLine("Selected New game");
                //Player newPlayer = new Player();
                createPlayer();
                //Create new player object
                //Get new information name, password, classtpye, race
                //Save into a file
                
                
            }
            else if (newgameChoice == "l")
            {
                string choice = "";
                choice = showAvailableProfile();

                if (choice == "y")
                {
                    checkInputPassword();
                    return;
                }
                else
                {
                    //newGame();
                }
            }
            else
            {
                Console.WriteLine("Please check input N or L");
                
            }
            
            

            
        }

        public static string showAvailableProfile()
        {
            string choice = "";
            String[] playerProfile = new string[4];
            playerProfile = loadProfile.LoadPlayerProfile();
            Console.WriteLine("Selected Load game");
            //load information from previous file
            Console.WriteLine("Available profile: " + playerProfile[0]);
            Console.WriteLine("Load " + playerProfile[0] + " ? [Y] or [N]");
            choice = Console.ReadLine().ToLower();
            return choice;
        }
        public static void checkInputPassword()
        {
            String[] playerProfile = new string[4];
            playerProfile = loadProfile.LoadPlayerProfile();
            string inputPassword;
            Console.WriteLine("Please enter your password");
            int attempts = 0;
            int attemptLimit = 5;
            int correct = 0;
         
            
            
            while (correct == 0)
            {

                inputPassword = getMaskedPasswordInput();
                if (inputPassword == playerProfile[1])
                {
                    Console.WriteLine("Welcome back " + playerProfile[0]);
                    Console.WriteLine("");
                    correct = 1;
                }
                else if(inputPassword != playerProfile[1] && attempts < attemptLimit)
                {
                    attempts += 1;
                    Console.WriteLine("Attemps remaining: " + (attemptLimit - attempts));
                    Console.WriteLine("Please re-enter your password");
                }
                if (inputPassword != playerProfile[1] && attempts == attemptLimit)
                {
                    Console.WriteLine("Incorrect password, contact support");
                }
            }


            /*if (inputPassword != playerProfile[1] && incorrecLimit > 0)
            {
                incorrecLimit--;
                Console.WriteLine("Incorrect Password!");
                Console.WriteLine("Please re enter password");
                incorrectCount = +1;
                Console.WriteLine("Attemps left: " + (incorrecLimit - incorrectCount));
                inputPassword = getMaskedPasswordInput();
            }
            else if(inputPassword != playerProfile[1] && incorrecLimit == 0) {
                Console.WriteLine("Incorrect password");

            }
            else
            {
                Console.WriteLine("welcome back " + playerProfile[0]);
            }
            /*while(inputPassword != playerProfile[1])
            {

                Console.WriteLine("Incorrect Password!");
                Console.WriteLine("Please re enter password");
                incorrectCount = +1;
                Console.WriteLine("Attemps left: " + (incorrecLimit - incorrectCount));
                inputPassword = getMaskedPasswordInput();
                
                
            }*/


        }
        public static Player getInfo()
        {
            string name;
            string password;
            string classType;
            string race;
            

            name = getName();
            password = getMaskedPassword();
            while(passwordValidation.checkPassword(password) != "y")
            {
                Console.WriteLine("Check password!");
                password = getMaskedPassword();
            }
            race = getRace();
            classType = getClass();
            saveState.saveProfile(name, password, race, classType);
            Player player = new Player(name, 100, 35, true, password, race, classType);
            return player;
        }

        public static Player createPlayer()
        {
            string name;
            string password;
            string classType;
            string race;


            name = getName();
            password = getMaskedPassword();
            while (passwordValidation.checkPassword(password) != "y")
            {
                Console.WriteLine("Check password!");
                password = getMaskedPassword();
            }
            race = getRace();
            classType = getClass();
            saveState.saveProfile(name, password, race, classType);
            Player player = new Player(name, 100, 35, true, password, race, classType);

            return player;


        }
        
        public static string getName()
        {
            string name;
            commonMessages.newNamePrompt();
            name = Console.ReadLine();
            return name;
        }
        public static string getPassword()
        {
            string password;
            commonMessages.newPasswordPrompt();
            password = Console.ReadLine();
            return password;
        }
        public static string getRace()
        {
            string race;
            commonMessages.newRacePrompt();
            race = Console.ReadLine();
            return race;
        }
        public static string getClass()
        {
            string classType;
            commonMessages.newClassPrompt();
            classType = Console.ReadLine();
            return classType;
        }

        public static string getMaskedPassword()
        {//This method is not mine, I found this online and it works for masking password
            string password = "";
            commonMessages.newPasswordPrompt();
            ConsoleKeyInfo info = Console.ReadKey(true);
            while (info.Key != ConsoleKey.Enter)
            {
                if (info.Key != ConsoleKey.Backspace)
                {
                    Console.Write("*");
                    password += info.KeyChar;
                }
                else if (info.Key == ConsoleKey.Backspace)
                {
                    if (!string.IsNullOrEmpty(password))
                    {
                        // remove one character from the list of password characters
                        password = password.Substring(0, password.Length - 1);
                        // get the location of the cursor
                        int pos = Console.CursorLeft;
                        // move the cursor to the left by one character
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                        // replace it with space
                        Console.Write(" ");
                        // move the cursor to the left by one character again
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                    }
                }
                info = Console.ReadKey(true);
                
            }

            Console.WriteLine();
            return password;
        }
        public static string getMaskedPasswordInput()
        {//This method is not mine, I found this online and it works for masking password
            string password = "";
            
            ConsoleKeyInfo info = Console.ReadKey(true);
            while (info.Key != ConsoleKey.Enter)
            {
                if (info.Key != ConsoleKey.Backspace)
                {
                    Console.Write("*");
                    password += info.KeyChar;
                }
                else if (info.Key == ConsoleKey.Backspace)
                {
                    if (!string.IsNullOrEmpty(password))
                    {
                        // remove one character from the list of password characters
                        password = password.Substring(0, password.Length - 1);
                        // get the location of the cursor
                        int pos = Console.CursorLeft;
                        // move the cursor to the left by one character
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                        // replace it with space
                        Console.Write(" ");
                        // move the cursor to the left by one character again
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                    }
                }
                
                info = Console.ReadKey(true);

            }

            Console.WriteLine();
            return password;
        }

    }
}
