﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class Map
    {
        public string Name { get; set; }

        public Map(string name)
        {
            Name = name;
        }
    }
}
