﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace dungeonCrawl01
{
    
    public class RandomGenerate
    {
        
        public static int randomNum()
        //used for genral % chances for drop/spawn rates 
        {
            Random random = new Random();
            int number;
            number = random.Next(0, 100);
            return number;
        }
        public static int randomNum_explicit(int number)
        //used for grabbing random items from lists/arrays, number should be the max index of the array/list it will pull from
        {
            Random random = new Random();
            int number1;
            number1 = random.Next(0, number);
            return number1;
        }
    }
}
