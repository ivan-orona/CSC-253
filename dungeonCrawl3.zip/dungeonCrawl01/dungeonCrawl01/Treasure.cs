﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class Treasure : Items
    {
        int _cost;
        public int cost
        {
            get { return _cost; }
            set { _cost = value; }
        }
        public Treasure(string name, string type, int cost) : base(name, type)
        {
            _cost = cost;
        }
    }
}
