﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class SpawnMonster
    {
        
        public static List<Mobs> copyOfMobList = generateArrays.LoadListMobs(); // copies contents of mobs list
        static Random randNum = new Random(); // generates random number
        
        
        
        public static Mobs spawnMob() {
            int randMob = randNum.Next(0, 4); //4 because we have 5 monsters
            Mobs monster = copyOfMobList[randMob];
           
            return monster;
   
        }


    }
}
