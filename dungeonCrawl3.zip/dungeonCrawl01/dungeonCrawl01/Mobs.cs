﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
   public class Mobs : Live_Entity
    {
        
        public string Type { get; set; }
     

       
        public Mobs(/*inhereted*/string name, int hp, int damage, bool alive, /*new*/string type): base(name, hp, damage, alive)
        {
            
            Type = type;
            
        }

       
    }
}
