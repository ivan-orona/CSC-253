﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace dungeonCrawl01
{
    public class generateArrays
    {
        static StreamReader inputFile;

       public static String[] LoadWeapons()
        {
            String[] weaponArray = new string[12];

            try
            {
                int index = 0;
                //opens Weapons.txt
                inputFile = File.OpenText("Weapons.txt");

                //used for storing string while iretating 
                String input;

                while (index < weaponArray.Length && !inputFile.EndOfStream)
                {
                    input = inputFile.ReadLine();//reads lines assigns it to input
                    weaponArray[index] = input; //assigns input to a new index from names array
                    index++;
                }

                inputFile.Close(); //close file


            }
            catch
            {
                Console.WriteLine("Check input file, missing Weapons.txt");

            }

            return weaponArray;

        }
        

        public static String[] LoadPotions()
        {
            String[] potionArray = new string[2];

            try
            {
                int index = 0;
                //opens Potions.txt
                inputFile = File.OpenText("Potions.txt");

                //used for storing string while iretating 
                String input;

                while (index < potionArray.Length && !inputFile.EndOfStream)
                {
                    input = inputFile.ReadLine();//reads lines assigns it to input
                    potionArray[index] = input; //assigns input to a new index from names array
                    index++;
                }

                inputFile.Close(); //close file


            }
            catch
            {
                Console.WriteLine("Check input file, missing Potions.txt");

            }

            return potionArray;

        }

        public static String[] LoadTreasure()
        {
            String[] treasureArray = new string[9];

            try
            {
                int index = 0;
                //opens Treasure.txt
                inputFile = File.OpenText("Treasures.txt");

                //used for storing string while iretating 
                String input;

                while (index < treasureArray.Length && !inputFile.EndOfStream)
                {
                    input = inputFile.ReadLine();//reads lines assigns it to input
                    treasureArray[index] = input; //assigns input to a new index from names array
                    index++;
                }

                inputFile.Close(); //close file


            }
            catch
            {
                Console.WriteLine("Check input file, missing Treasures.txt");

            }

            return treasureArray;

        }

        public static String[] LoadMap()
        {
            String[] mapArray = new string[5];

            try
            {
                int index = 0;
                //opens Map.txt
                inputFile = File.OpenText("Map.txt");

                //used for storing string while iretating 
                String input;

                while (index < mapArray.Length && !inputFile.EndOfStream)
                {
                    input = inputFile.ReadLine();//reads lines assigns it to input
                    mapArray[index] = input; //assigns input to a new index from names array
                    index++;
                }

                inputFile.Close(); //close file


            }
            catch
            {
                Console.WriteLine("Check input file, missing Map.txt");

            }

            return mapArray;

        }

        public static String[] LoadItems()
        {
            String[] itemsArray = new string[9];

            try
            {
                int index = 0;
                //opens Items.txt
                inputFile = File.OpenText("Items.txt");

                //used for storing string while iretating 
                String input;

                while (index < itemsArray.Length && !inputFile.EndOfStream)
                {
                    input = inputFile.ReadLine();//reads lines assigns it to input
                    itemsArray[index] = input; //assigns input to a new index from names array
                    index++;
                }

                inputFile.Close(); //close file


            }
            catch
            {
                Console.WriteLine("Check input file, missing Items.txt");

            }

            return itemsArray;

        }

        public static String[] LoadMobs()
        {
            String[] monsterArray = new string[30];

            try
            {
                int index = 0;
                //opens Monsters.txt
                inputFile = File.OpenText("Monsters.txt");

                //used for storing string while iretating 
                String input;

                while (index < monsterArray.Length && !inputFile.EndOfStream)
                {
                    input = inputFile.ReadLine();//reads lines assigns it to input
                    monsterArray[index] = input; //assigns input to a new index from names array
                    index++;
                }

                inputFile.Close(); //close file


            }
            catch
            {
                Console.WriteLine("Check input file, missing Monsters.txt");

            }

            return monsterArray;

        }


       public static void Test()
        {
            Console.WriteLine("Testing Arrays");
            foreach (string weapon in generateArrays.LoadWeapons())
            {
                Console.Write(weapon + " ");
            }
            Console.WriteLine("\nTesting Arrays");
            foreach (string potion in generateArrays.LoadPotions())
            {
                Console.Write(potion + " ");
            }
            Console.WriteLine("\nTesting Arrays");
            foreach (string treasure in generateArrays.LoadTreasure())
            {
                Console.Write(treasure + " ");
            }

            Console.WriteLine("\nTesting Arrays");
            foreach (string room in generateArrays.LoadMap())
            {
                Console.Write(room + " ");
            }
        }

        //##################################################################################################################################################
        public static Weapons[] LoadWeaponsObj()
        {
            Weapons[] weaponArray = new Weapons[4];
            string[] dummyArray = LoadWeapons();

            int index = 0;
           
            int first = 0;
            int second = 1;
            int third = 2;
               
            while (index < weaponArray.Length)
            {
                Weapons weapon = new Weapons(dummyArray[first],dummyArray[second], int.Parse(dummyArray[third]));
                weaponArray[index] = weapon; //assigns input to a new index from names array
                index++;
                first += 3;
                second +=3;
                third += 3;
            }

            return weaponArray;

        }
        public static Treasure[] LoadTreasureObj()
        {
            Treasure[] treasureArray = new Treasure[3];
            string[] dummyArray = LoadTreasure();

            int index = 0;
           
            int first = 0;
            int second = 1;
            int third = 2;

            while (index < treasureArray.Length)
            {
                Treasure treasure = new Treasure(dummyArray[first], dummyArray[second], int.Parse(dummyArray[third]));
                treasureArray[index] = treasure; //assigns input to a new index from names array
                index++;
                first += 3;
                second += 3;
                third += 3;
            }

            return treasureArray;
        }

        public static Map[] LoadMapObj()
        {
            Map[] mapArray = new Map[5];
            string[] dummyArray = LoadMap();

            int index = 0;

            int first = 0;
          
            while (index < mapArray.Length)
            {
                Map map = new Map(dummyArray[first]);
                mapArray[index] = map; //assigns input to a new index from names array
                index++;
                first += 1;
               
            }

            return mapArray;

        }

        public static Items[] LoadItemsObj()
        {
            Items[] itemsArray = new Items[3];
            string[] dummyArray = LoadItems();

            int index = 0;

            int first = 0;
            int second = 1;
            int third = 2;

            while (index < itemsArray.Length)
            {
                Items item = new Items(dummyArray[first], dummyArray[second]);
                itemsArray[index] = item; //assigns input to a new index from names array
                index++;
                first += 3;
                second += 3;
                third += 3;
            }

            return itemsArray;
        }
        public static Mobs[] LoadMobsObj()
        {
            Mobs[] mobArray = new Mobs[5];
            string[] dummyArray = LoadMobs();

            int index = 0;

            int first = 0;
            int second = 1;
            int third = 2;
            int fourth = 3;
            int fifth = 4;

            while (index < mobArray.Length)
            {
                Mobs monster = new Mobs(dummyArray[first], int.Parse(dummyArray[second]), int.Parse(dummyArray[third]), bool.Parse(dummyArray[fourth]), dummyArray[fifth]);
                mobArray[index] = monster; //assigns input to a new index from names array
                index++;
                first += 5;
                second += 5;
                third += 5;
                fourth += 5;
                fifth += 5;
            }

            return mobArray;
        }

        public static List<Mobs> LoadListMobs()
        {
            List<Mobs> Monster = new List<Mobs>();

            Mobs[] dummyArray = LoadMobsObj();

            foreach (Mobs monster in dummyArray)
            {
                Monster.Add(monster);
            }


            return Monster;
        }
    }
    
}
