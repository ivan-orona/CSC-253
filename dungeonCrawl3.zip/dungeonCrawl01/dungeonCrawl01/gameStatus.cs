﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    class gameStatus
    {
        public static void gameState(int index)
        {
            Player player = saveState.player;
            //generates random number 0-100 used fo randomb chance fo spawning a monster
            Console.WriteLine("\nYou are currently in: " + Program.map[index]);
            Console.WriteLine("your commands are N for north, S for South and E for exit and L for lookup");
            Random rand = new Random();
            try
            {
                string userInput;
                userInput = Console.ReadLine().ToLower();

                //If user wants to move North, we add + 1 to the global variable thats holds the current index of the array, then calls gamState()
                if (userInput == "n")
                {
                    Mobs currentMonster = SpawnMonster.spawnMob();//spawns random mob (from copy of master list)
                    
                    if (Program.globalINT < 4)
                    {
                        int chance = rand.Next(0, 100);
                        //Console.WriteLine("Rand numb = " + chance);
                        //Console.WriteLine("Rand mob test = " + currentMonster._Name);
                        Console.ForegroundColor = ConsoleColor.White;
                        Program.globalINT = Program.globalINT + 1;
                        
                        if (chance < 50)
                        {
                            string innerchoice = "";

                            Console.WriteLine("Careful! a " + currentMonster._Name + "has spawned!");
                            Console.WriteLine("You can attack or move along [N/S]. Press [A] to attack");
                            innerchoice = Console.ReadLine().ToLower();

                            if (innerchoice == "a")
                            {
                                Combat.Attack(player, currentMonster);
                            }
                            else
                            {
                                gameState(Program.globalINT);
                            }
                        }

                        gameState(Program.globalINT);


                    }
                    /*if (chance < 50)
                    {

                        string innerchoice = "";

                        Console.WriteLine("Careful! a " + currentMonster._Name + "has spawned!");
                        Console.WriteLine("You can attack or move along [N/S]. Press [A] to attack");
                        innerchoice = Console.ReadLine().ToLower();

                        if (innerchoice == "a")
                        {
                            Combat.Attack(player, currentMonster);
                        }
                        else
                        {
                            gameState(Program.globalINT);
                        }
                    }*/

                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine("There is no way out North");
                        gameState(Program.globalINT);

                    }


                }
            
                //If user wants to move south, we subtract - 1 to the global variable that holds the current index of the array, then calls gamState().
                if (userInput == "s")
                {
                    int chance = rand.Next(0, 100);
                    if (Program.globalINT > 0)

                    {
                        Mobs currentMonster = SpawnMonster.spawnMob();
                        Console.ForegroundColor = ConsoleColor.White;
                        Program.globalINT = Program.globalINT - 1;
                        
                        if (chance < 50)
                        {
                            string innerchoice = "";

                            Console.WriteLine("Careful! a " + currentMonster._Name + "has spawned!");
                            Console.WriteLine("You can attack or move along. Press [A] to attack");
                            innerchoice = Console.ReadLine().ToLower();

                            if (innerchoice == "a")
                            {
                                Combat.Attack(player, currentMonster);
                            }
                            else
                            {
                                gameState(Program.globalINT);
                            }


                        }

                        gameState(Program.globalINT);

                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine("There is no way out South");
                        gameState(Program.globalINT);
                    }
                }
                //Used for exiting application
                if (userInput == "e")
                {
                    Console.WriteLine("Good Bye");
                    Environment.Exit(0);
                }
                if (userInput == "l")
                {
                    Weapons[] dummyArray = generateArrays.LoadWeaponsObj();
                    string userChoice;
                    Console.WriteLine("Available Items to lookup:(Slect by entering corresponding number) \n1.Sword\n2.Bow\n3.Mace\n4.Axe");
                    userChoice = Console.ReadLine();
                    if (userChoice == "1")
                    {
                        Console.WriteLine("Name: "+ dummyArray[0].Name + "\nAttack type: "+ dummyArray[0].Type + "\nDamage: " + dummyArray[0].damage);
                        gameState(Program.globalINT);
                    }
                    else if (userChoice == "2")
                    {
                        Console.WriteLine("Name: " + dummyArray[1].Name + "\nAttack type: " + dummyArray[1].Type + "\nDamage: " + dummyArray[1].damage);
                        gameState(Program.globalINT);
                    }
                    else if (userChoice == "3")
                    {
                        Console.WriteLine("Name: " + dummyArray[2].Name + "\nAttack type: " + dummyArray[2].Type + "\nDamage: " + dummyArray[2].damage);
                        gameState(Program.globalINT);
                    }
                    else if (userChoice == "4")
                    {
                        Console.WriteLine("Name: " + dummyArray[3].Name + "\nAttack type: " + dummyArray[3].Type + "\nDamage: " + dummyArray[3].damage);
                        gameState(Program.globalINT);
                    }
                    else
                    {
                        Console.WriteLine("Incorrect choice");
                        gameState(Program.globalINT);
                    }
                }
            }
            //Catch any error and will display message.
            catch
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Incorrect input! Your commands are N for North S for South and E for exit");
                gameState(Program.globalINT);
            }
        }
    }
}
