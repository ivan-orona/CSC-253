﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class Weapons : Items
    {
        int _damage;
        public int damage
        {
            get { return _damage; }
            set { _damage = value; }
        }
        public Weapons(string name, string type, int damage) : base(name, type)
        {
            _damage = damage;
        }
    }
}
