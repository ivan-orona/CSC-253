﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class Items
    {
        string _Name;
        string _Type;
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        public Items(string name, string type)
        {
            _Name = name;
            _Type = type;
        }
    }
}
