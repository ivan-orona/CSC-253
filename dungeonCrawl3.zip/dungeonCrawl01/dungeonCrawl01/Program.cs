﻿/**
* October 2, 2018
* CSC 253
* Michael Villafan & Ivan Orona
* This program will display a prompt message for the user to use two different
* keys to maneuvar through a console interface with an option to quit. The 
* program will allow the user to move back and forth in between rooms 
* while also informing the player where they are.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    class Program
    {
        //Used for array index
        public static int globalINT = 0;
        //Will be used in th efuture - static int inventoryLimit = 7;
        static string userInput = "";
        static Random random = new Random();

        //Arrays for rooms, weapons, potions and treasures
        /*static String[] roomArray = new string[] { "Town", "Wilderness", "Cave", "Abandoned Church", "Boss Lair" };
        static String[] weaponArray = new string[] { "Sword", "Bow", "Mace", "Battle Axe" };
        static String[] potionArray = new string[] { "Mana Potion", "Health Potion" };
        static String[] treasureArray = new string[] { "Magic Key", "Strength Stone", "Black Gem" };*/
        //Lists for items and mobs
        public static List<string> items = new List<string>();
        public static List<string> mobs = new List<string>();
        public static List<string> weaponsInventory = new List<string>();
        public static List<string> items_potionsInventory = new List<string>();
        public static List<string> treasureInventory = new List<string>();
        public static List<string> map = new List<string>(generateArrays.LoadMap());
        static void Main(string[] args)
        {
            /*Used for testing  generated objects
            foreach (Weapons we in generateArrays.LoadWeaponsObj()) {
                Console.WriteLine(we.Name + we.Type + we.Damage);
            }

            foreach (Treasure we in generateArrays.LoadTreasureObj())
            {
                Console.WriteLine(we.Name + we.Type + we.Cost);
               
            }
            foreach (Map we in generateArrays.LoadMapObj())
            {
                Console.WriteLine(we.Name);
            }
            foreach (Items we in generateArrays.LoadItemsObj())
            {
                Console.WriteLine(we.Name + we.Type + we.Health);
            }
            foreach (Mobs we in generateArrays.LoadMobsObj())
            {
                Console.WriteLine(we.Name + we.Type + we.Damage);
            }
            */

           


            
            //Add items to listss
            generateLists.populateLists(items, mobs);
            //Prints intro graphic, should be changed later
            graphictest.introScreen();

            //testing spawning monster
           /* string name = SpawnMonster.spawnMob(RandomGenerate.randomNum_explicit(4))._Name;
            int hp = SpawnMonster.spawnMob(RandomGenerate.randomNum_explicit(4))._HP;
            int damage = SpawnMonster.spawnMob(RandomGenerate.randomNum_explicit(4))._Damage;
            bool isAlive = SpawnMonster.spawnMob(RandomGenerate.randomNum_explicit(4))._Alive;
            string type = SpawnMonster.spawnMob(RandomGenerate.randomNum_explicit(4)).Type;

            Console.WriteLine("Testing monster generate, name, hp, dmg, alive, type"+ name+ hp.ToString()+ damage.ToString()+ isAlive.ToString()+ type);*/
            gameStart.newGame();
            
            gameStatus.gameState(globalINT);

            
           
        }//Main Bracket

        
    }
}
//End program.