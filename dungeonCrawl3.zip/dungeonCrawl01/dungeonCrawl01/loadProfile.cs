﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace dungeonCrawl01
{
    class loadProfile
    {
        
        public static String[] LoadPlayerProfile()
        {
            StreamReader inputFile;
            String[] playerProfile = new string[4];
            /*
             * 0 = name
             * 1 = password
             * 2 = race
             * 3 = class type
             */

            try
            {
                int index = 0;
                //opens Potions.txt
                inputFile = File.OpenText("Profile.txt");

                //used for storing string while iretating 
                String input;

                while (index < playerProfile.Length && !inputFile.EndOfStream)
                {
                    input = inputFile.ReadLine();//reads lines assigns it to input
                    playerProfile[index] = input; //assigns input to a new index from names array
                    index++;
                }

                inputFile.Close(); //close file


            }
            catch
            {
                Console.WriteLine("Check input file, missing Potions.txt");

            }

            return playerProfile;

        }
    }
}
