﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class passwordValidation
    {
        
        public static int NumberUpperCase(string str)
        {
            int upperCase = 0;

            foreach (char ch in str)
            {
                if (char.IsUpper(ch))
                {
                    upperCase++;
                }
            }
            return upperCase;
        }
        public static int NumberLowerCase(string str)
        {
            int lowerCase = 0;

            foreach (char ch in str)
            {
                if (char.IsLower(ch))
                {
                    lowerCase++;
                }
            }
            return lowerCase;
        }
        public static int NumberSpecial(string str)
        {
            int specialChar = 0;

            foreach (char ch in str)
            {
                if (char.IsSymbol(ch) || char.IsPunctuation(ch))
                {
                    specialChar++;
                }
            }
            return specialChar;
        }
        public static int NumberNumber(string str)
        {
            int number = 0;

            foreach (char ch in str)
            {
                if (char.IsDigit(ch))
                {
                    number++;
                }
            }
            return number;
        }
        public static string checkPassword(string password)
        {
            const int MIN_LENGTH = 8;
            
            string confirmation = "";
            

            // Validate password.
            if (password.Length >= MIN_LENGTH &&
                NumberUpperCase(password) >= 1 &&
                NumberLowerCase(password) >= 1 &&
                NumberSpecial(password) >= 1 &&
                NumberNumber(password) >= 1)
            {
                Console.WriteLine("The password is valid!");
                confirmation = "y";
            }
            else if (password.Length >= MIN_LENGTH &&
                NumberUpperCase(password) == 0 &&
                NumberLowerCase(password) >= 1 &&
                NumberSpecial(password) >= 1&&
                NumberNumber(password) >= 1)
            {
                Console.WriteLine("The password is not valid! Please include an upper case letter!");
            }
            else if (password.Length >= MIN_LENGTH &&
               NumberUpperCase(password) >= 1 &&
               NumberLowerCase(password) == 0 &&
               NumberSpecial(password) >= 1 &&
               NumberNumber(password) >= 1)
            {
                Console.WriteLine("The password is valid! Please include a lower case letter!");
            }
            else if (password.Length >= MIN_LENGTH &&
               NumberUpperCase(password) >= 1 &&
               NumberLowerCase(password) >= 1 &&
               NumberSpecial(password) == 0 &&
               NumberNumber(password) >= 1)
            {
                Console.WriteLine("The password is invalid! Please include a special character/symbol!");
            }
            else if (password.Length < MIN_LENGTH &&
                NumberUpperCase(password) >= 1 &&
                NumberLowerCase(password) >= 1 &&
                NumberSpecial(password) >= 1 &&
                NumberNumber(password) >= 1)
            {
                Console.WriteLine("The password is valid! Must be at least 8 characters!");
            }
            else if (password.Length >= MIN_LENGTH &&
                NumberUpperCase(password) >= 1 &&
                NumberLowerCase(password) >= 1 &&
                NumberSpecial(password) >= 1 &&
                NumberNumber(password) == 0)
            {
                Console.WriteLine("The password is invalid! Needs to have at least 1 number");
                
            }
            else
            {
                Console.WriteLine("Sorry! There was an error with your password entry. Please Try again.");
            }
            return confirmation;
        }
    }
}

