﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class Combat
    {
        public static void Attack(Player Player, Mobs Monster) {

            string choice = "a";

            while ((Player._Alive == true && Monster._Alive ==true && choice == "a")|| (Player._Alive == true && Monster._Alive == true && choice == "p")) {
         
                Player._HP -= Monster._Damage;
                Monster._HP -= Player._Damage;

                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("You attacked " + Monster._Name + " for: "); Console.ForegroundColor = ConsoleColor.Red;
                Console.Write(Player._Damage); Console.ForegroundColor = ConsoleColor.White;
                Console.Write(" remaining HP: "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Monster._HP); Console.ForegroundColor = ConsoleColor.White;

                Console.WriteLine("");
                Console.Write(Monster._Name + " attacked you for "); Console.ForegroundColor = ConsoleColor.Red;
                Console.Write(Monster._Damage); Console.ForegroundColor = ConsoleColor.White;
                Console.Write(" your remaining HP: "); Console.ForegroundColor = ConsoleColor.Green; Console.Write(Player._HP);

                Console.ForegroundColor = ConsoleColor.White;

                Console.WriteLine("");
                if (Player._HP <= 0)
                {
                    Player._Alive = false;

                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    graphictest.gameOver();
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("\n\nPress any key to exit");
                    Console.Read();

                }
                if (Monster._HP <= 0)
                {
                    //CHECK PLZ DOUBLE CHECK 
                    //CHECK THAT MONSTER DIES
                    Monster._Alive = false; Console.WriteLine(Monster._Name + " has died");
                    SpawnMonster.copyOfMobList.Remove(Monster);
                }

                if (Player._HP > 0 && Monster._HP > 0)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("\nAttack again: [A] Flee: [F]");
                    choice = Console.ReadLine().ToLower();

                    /*if (choice == "p")
                    {
                        Player._HP += 50;
                        Console.WriteLine("You used  HP potion and it healed you for: 50HP");
                        Console.WriteLine("Current HP: "+Player._HP);
                        return;
                    }*/
                }
                

            }
            


        }

        
    }
}
