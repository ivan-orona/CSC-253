﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class Player : Live_Entity
    {
        
        public string _Password { get; set; }
        public string _Race { get; set; }
        public string _ClassType { get; set; }

        public Player(string name, int hp, int damage, bool alive, string password, string race, string classtype) : base(name, hp, damage, alive) {

            _Password = password;
            _Race = race;
            _ClassType = classtype;
        }

        
    }
}
