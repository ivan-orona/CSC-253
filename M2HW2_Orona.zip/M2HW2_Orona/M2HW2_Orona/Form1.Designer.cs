﻿namespace M2HW2_Orona
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.viewTeamButton = new System.Windows.Forms.Button();
            this.checkTeamButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.outputTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // viewTeamButton
            // 
            this.viewTeamButton.Location = new System.Drawing.Point(118, 435);
            this.viewTeamButton.Name = "viewTeamButton";
            this.viewTeamButton.Size = new System.Drawing.Size(116, 23);
            this.viewTeamButton.TabIndex = 0;
            this.viewTeamButton.Text = "View Teams";
            this.viewTeamButton.UseVisualStyleBackColor = true;
            this.viewTeamButton.Click += new System.EventHandler(this.viewTeamButton_Click);
            // 
            // checkTeamButton
            // 
            this.checkTeamButton.Location = new System.Drawing.Point(118, 474);
            this.checkTeamButton.Name = "checkTeamButton";
            this.checkTeamButton.Size = new System.Drawing.Size(116, 23);
            this.checkTeamButton.TabIndex = 1;
            this.checkTeamButton.Text = "Check Team Wins";
            this.checkTeamButton.UseVisualStyleBackColor = true;
            this.checkTeamButton.Click += new System.EventHandler(this.checkTeamButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(118, 541);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(116, 23);
            this.clearButton.TabIndex = 2;
            this.clearButton.Text = "Refresh";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(84, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(178, 394);
            this.listBox1.TabIndex = 3;
            // 
            // outputTextBox
            // 
            this.outputTextBox.Location = new System.Drawing.Point(83, 580);
            this.outputTextBox.Name = "outputTextBox";
            this.outputTextBox.Size = new System.Drawing.Size(179, 20);
            this.outputTextBox.TabIndex = 4;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(118, 627);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(116, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(96, 511);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "(Please refresh after every check)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 663);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.outputTextBox);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.checkTeamButton);
            this.Controls.Add(this.viewTeamButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button viewTeamButton;
        private System.Windows.Forms.Button checkTeamButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox outputTextBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label1;
    }
}

