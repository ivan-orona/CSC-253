﻿/**
* October 4, 2018
* CSC 253
* Miguel Ivan Orona
* This program will allow prompt the user to choose a listed bsaeball team
* and the program will process two files into two seperate lists. When 
* the user chooses a team, the program will loop through the list 
* and searching for the matching team, displaying the number of wins.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW2_Orona
{
    public partial class Form1 : Form
    {
        List<string> teamList = new List<string>();     //List to hold the team text file.
        List<string> winnerList = new List<string>();   //List to hold the World Series Winners file.

        public Form1()
        {
            InitializeComponent();
        }
        private void ReadTeams()    //Reads the text file into a list.
        {
            try
            {
                StreamReader inputFileTeams = File.OpenText("Teams.txt");
                string holder;
                while (!inputFileTeams.EndOfStream)
                {
                    holder = inputFileTeams.ReadLine(); //Reads each line into a variable.
                    teamList.Add(holder);   //Adds each variable (line) to the teamList.
                }
                inputFileTeams.Close(); //Closes the file.

                foreach(string i in teamList)   //Will display each line to listBox1.
                {
                    listBox1.Items.Add(i);
                }
            }
            catch
            {
                MessageBox.Show("An error has occurred within the program!");
            }
        }

        private void ReadWinner()   //Reads the text file into a list
        {
            try
            {
                StreamReader inputFileWinners = File.OpenText("WorldSeriesWinners.txt");
                string holder;

                while (!inputFileWinners.EndOfStream)
                {
                    holder = inputFileWinners.ReadLine();
                    winnerList.Add(holder);
                }
                inputFileWinners.Close();
            }
            catch
            {
                MessageBox.Show("An error has occurred within the program!");
            }
        }
        private int CheckWinner(List<string> teamList)  
        {
            int total = 0;  
            int index = 0;
            string userInput;

            //Holds the user's selected team to a variable
            userInput = listBox1.SelectedItem.ToString();

                while (index < teamList.Count)  
                {
                    if (teamList[index] == userInput)   //Searches for matching string names.
                    {
                        total++;    //Adds to the total accumulator.
                    }
                    index++;    //Adds to the index so that the next line would be checked.
                }
            return total;   //Returns the final total.

        }

        private void viewTeamButton_Click(object sender, EventArgs e)
        {
            //Calls each method.
            ReadTeams();
            ReadWinner();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears boxes to be refreshed
            outputTextBox.Clear();
            listBox1.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the file.
            this.Close();
        }

        private void checkTeamButton_Click(object sender, EventArgs e)
        {
            
            int total;
            total = CheckWinner(teamList);  //Holds the count into a variable.
            outputTextBox.Text = ("That team has won " + total + " times!");
        }
    }
}
//End of program.