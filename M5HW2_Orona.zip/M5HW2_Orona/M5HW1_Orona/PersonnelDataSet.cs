﻿namespace M5HW1_Orona
{


    partial class PersonnelDataSet
    {
    }
}

namespace M5HW1_Orona.PersonnelDataSetTableAdapters
{
    
}
