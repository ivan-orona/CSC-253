﻿/**
* 11/14/2018
* CSC 253
* Miguel Ivan Orona
* This program will display a created table and 
* allow the user to sort through the table either
* through ascending or descending order.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M5HW1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ascButton_Click(object sender, EventArgs e)
        {
            //Orders the database list by ascending order.
            this.employeeTableAdapter.FillByPayRate(this.personnelDataSet.Employee);
        }

        private void descButton_Click(object sender, EventArgs e)
        {
            //Orders the database list by descending order.
            this.employeeTableAdapter.FillByDescPayRate(this.personnelDataSet.Employee);
        }
    }
}
//End program.