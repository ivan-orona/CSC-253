﻿/**
* 10/8/2018
* CSC 253
* Miguel Ivan Orona
* This program will prompt the user to enter various integers and 
* the program will put the input into an array and call a method 
* that will add all the integers together & display the sum.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Accepting the array as as an argument for the ShowCount method.
        private void ShowSum(string[] tokens)
        {
            int sum = 0;  //Initializes the count variable.
            for (int i = 0; i < tokens.Length; i++)
            {
                //Reading the integers and adding them into the sum.
                sum += int.Parse(tokens[i]);
            }
            //Displays the sum of integers.
            outputTextBox.Text = sum.ToString();
        }
        private void countButton_Click(object sender, EventArgs e)
        {
            try
            {
                string userString = inputTextBox.Text;  //Accepts user input into a variable.
                char[] delim = { ',' }; //Assigns the comma as a delimiter.
                string[] tokens = userString.Split(delim);   //Splits & tokenizes the string into an array.
                ShowSum(tokens);  //Calls the ShowSum method.
            }
            catch
            {
                //throws an error message
                MessageBox.Show("Input Error! Please ensure that your INTEGER & not letter input is separated" + "" +
                    " by commas, but does not end with a comma!");
            } 
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears the boxes
            inputTextBox.Clear();
            outputTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }
    }
}//End program
