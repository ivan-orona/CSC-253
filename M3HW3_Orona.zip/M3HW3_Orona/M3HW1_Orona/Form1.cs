﻿/**
* 10/8/2018
* CSC 253
* Miguel Ivan Orona
* This program will prompt the user to enter various integers and 
* the program will tokenize the array and call a method 
* that will capitilze the first character in each sentence.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void ShowCaps(string[] tokens)
        {
            foreach (string x in tokens) //Foreach loop to change each string in the array.
            {
                string s = (x.TrimStart());    //Trimming whitespace.
                if (s == "")    //If the string is empty (or whitespace), it will be ignored.
                {
                    break;
                }
                else if (char.IsLower(s[0]))    //If the first character in the string is lowercase,
                                                //this will capitilize to upperCase.
                {
                    string zeroSpot = s[0].ToString();
                    string removeZero = s.Remove(0, 1);
                    string finalSent = (zeroSpot.ToUpper() + removeZero);

                    outputTextBox.Text += "." + finalSent; //Outputting the 
                }
                else
                {
                    MessageBox.Show("incorrect input"); //Throws an an error if the input is anything other than a string.
                }
            }

        }
        private void countButton_Click(object sender, EventArgs e)
        {
            char[] delim = { '.','?','!', }; //Assigns punctuation as delimiters.
            string userString = inputTextBox.Text;  //Accepts user input into a variable.

            string[] tokens = userString.Split(delim);   //Splits & tokenizes the string into an array.
            ShowCaps(tokens); //Calls the showcaps method and passes the tokenized array
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears the boxes
            inputTextBox.Clear();
            outputTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }
    }
}//End program
