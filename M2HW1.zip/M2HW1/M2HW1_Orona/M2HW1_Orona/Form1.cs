﻿/**
* September 10, 2018
* CSC 253
* Miguel Ivan Orona
* This program will prompt the user to press the calculate button and the
* program will read a text file and output the contents.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Reads the text file into the variable inputFile.
                StreamReader inputFile = File.OpenText("Sales.txt");
                
                int counter = 0;  //Counter

                //The array to hold each line (sale).
                decimal[] sales = new decimal[7];

                //Loop that reads each line as a decimal and adds to the running total.
                while (!inputFile.EndOfStream && counter < sales.Length)
                {
                    sales[counter] = decimal.Parse(inputFile.ReadLine());
                    counter++;
                }
                //Closes the file
                inputFile.Close();

                //Holds the variable for the final ouput that will be displayed.
                decimal finalTotal = 0;

                
                for (int index = 0; index < counter; index++)
                {
                    outputListBox.Items.Add("This sale: " +sales[index]);
                    finalTotal += sales[index];
                }
                //Adds the running total final to the end of the list.
                outputListBox.Items.Add("The total sales is: " + finalTotal.ToString());
                
            }
            catch
            {
                //Displays an error message if anything goes wrong within the program.
                MessageBox.Show("Error!");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program.
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
    }
}
//End of program.