﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M1HW2_OronaMiguel
{
    public static class Converters
    {
        public static double converters(String input)
        {
            double totalMaxDays;
            double.TryParse(input, out totalMaxDays);
            return totalMaxDays;
        }

        public static Double ToDouble(string inputMaxDays)
        {
            double totalMaxDays;
            double.TryParse(inputMaxDays, out totalMaxDays);
            return totalMaxDays;
        }
    }
}
