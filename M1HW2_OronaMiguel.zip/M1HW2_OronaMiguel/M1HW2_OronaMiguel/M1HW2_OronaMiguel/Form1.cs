﻿/**
* August 27, 2018
* CSC 253
* Miguel Ivan Orona
* This program will prompt the user to enter a number of days they worked
* and will recieve a starting pay of one penny that will be doubled each day
* and output the information.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW2_OronaMiguel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                double pennyTotal = 1;
                double totalPay = 0;
                double dayCount = 0;
                double daysWorked = 0;
                double inputDays = double.Parse(inputTextBox.Text);

                while (daysWorked < inputDays)
                {
                    daysWorked++;       //adds 1 day worked to the accumulator, will stop once input number is met. 
                    dayCount++;         //adds 1 day to the day counter.
                    outputListBox.Items.Add("For day " + dayCount + " the pay is: " + pennyTotal + " cents");   //Displays the ouput.
                    pennyTotal = pennyTotal * 2;
                }
                outputListBox.Items.Add("The total pay is: " + pennyTotal);
            }
            catch (Exception ex)
            {   
                //Error message displayed. 
                outputListBox.Items.Add("Invalid input!");  
            }
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program.
            this.Close();
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {   
            //Clears boxes 
            inputTextBox.Clear();
            outputListBox.Items.Clear();
        }
    }
}
//End Program.
