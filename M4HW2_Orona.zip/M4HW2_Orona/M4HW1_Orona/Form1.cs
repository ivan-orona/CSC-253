﻿/**
* 10/30/2018
* CSC 253
* Miguel Ivan Orona
* This program will utilize user input to create an employee 
* object and display the information through the class 
* methods to include an derived class. The program will also 
* allow a supervisor to input their information and place the
* information in a class as well before outputting it back.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            string firstName = firstNameInputBox.Text;  //Holds the users name input
            string employeeNumber = empNumTextBox.Text; //Employee number
            int shift = int.Parse(shiftTextBox.Text);   //Entered shift.
            double payRate = double.Parse(payRateTextBox.Text); //Pay rate that is entered

            int supervisorSalary = int.Parse(inputSalaryTextBox.Text);  //Var(s) from textbox
            int supervisorBonus = int.Parse(inputProductionTextBox.Text);   

            //Creates a new employee object. 
            ProductionWorker EmployeeSecond = new ProductionWorker(firstName, employeeNumber,shift, payRate);

            //Creates a supervisor object.
            ShiftSupervisor Supervisor = new ShiftSupervisor(firstName, employeeNumber, supervisorBonus, supervisorSalary);

            //Outputs the information to textboxes.
            nameNumberOuputTextBox.Text = (EmployeeSecond.PeronalCheck() + EmployeeSecond.ShiftCheck());
            supervisorOutputTextBox.Text = (Supervisor.PeronalCheck() + Supervisor.SupervisorCheck());
        }

        private void restartButton_Click(object sender, EventArgs e)
        {
            //Clears all text boxes/
            firstNameInputBox.Clear();
            empNumTextBox.Clear();
            shiftTextBox.Clear();
            payRateTextBox.Clear();
            nameNumberOuputTextBox.Clear();
            supervisorOutputTextBox.Clear();
            inputProductionTextBox.Clear();
            inputSalaryTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }
    }
}
//End of program.