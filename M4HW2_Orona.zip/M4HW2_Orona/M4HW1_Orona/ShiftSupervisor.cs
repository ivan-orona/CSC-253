﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M4HW1_Orona
{
    //Extending the employee class.
    class ShiftSupervisor : Employee
    {
        
        private int annualSalary;
        private int annualBonus;

        public ShiftSupervisor(string name, string employeeNumber,/*new*/ int salary, int bonus) : base(name, employeeNumber)
        {
            annualSalary = salary;
            annualBonus = bonus;
        }
        public ShiftSupervisor()
        {
            annualSalary = 0;
            annualBonus = 0;
        }
        public void setSalary(int salary)
        {
            annualSalary = salary;
        }
        public void setBonus(int bonus)
        {
            annualBonus = bonus;
        }
        public int getSalary()
        {
            return annualSalary;
        }
        public double getBonus()
        {
            return annualBonus;
        }
        public string SupervisorCheck()
        {
            string str = " Annual Salary: " + annualSalary + " Annual Bonus: " + annualBonus;
            return str;
        }
    }
}
