﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M4HW1_Orona
{
    //Employee Class
    class Employee 
    {
        private string name;    //Holds for employee name.
        private string employeeNumber;  //Holds employee number.

        public Employee(String n, String num)
        {
            name = n;
            employeeNumber = num;
        }
        public Employee()
        {
            name = "";
            employeeNumber = "";
        }
        public void setName(string n)
        {
            name = n;
        }
        public void setEmployeeNumber(string e)
        {
                employeeNumber = "";
        }
       
        public string getName()
        {
            return name;
        }
        public String getEmployeeNumber()
        {
            return employeeNumber;
        }


        public string PeronalCheck()
        {
            string str = " Name: " + name + " Employee Number: ";

            if (employeeNumber == "")
            {
                return str += " Invalid Employee Number";
            }
            else
            {
                str += employeeNumber;
                return str;
            }
        }
    }
}
//End class