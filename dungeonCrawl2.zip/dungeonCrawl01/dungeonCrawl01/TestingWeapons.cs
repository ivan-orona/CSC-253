﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    /*class TestingWeapons
    {
        public static Weapons generateObject() {

            foreach (string s in generateArrays.LoadWeapons())
            {

            } 


        
    }*/
}
