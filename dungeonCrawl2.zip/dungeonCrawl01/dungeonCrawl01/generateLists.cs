﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class generateLists
    {
        public static void populateLists(List<string> items, List<string> mobs)
        {
            items.Add("Town Portal");
            items.Add("Boss Portal");
            items.Add("Ameulet");
            items.Add("Ring");
            mobs.Add("Zombie");
            mobs.Add("Skeleton");
            mobs.Add("Ghost");
            mobs.Add("Lesser Demon");
            mobs.Add("Giant Spider");
        }
    }
}
