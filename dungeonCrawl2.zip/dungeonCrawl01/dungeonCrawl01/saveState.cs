﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace dungeonCrawl01
{
    class saveState
    {
        public static void saveProfile(string name, string password, string race, string classType)
        {
            string _name = name;
            string _password = password;
            string _race = race;
            string _classType = classType;
            

            try
            {
                StreamWriter outPutFile;
                outPutFile = File.CreateText("Profile.Txt");
                outPutFile.WriteLine(_name);
                outPutFile.WriteLine(_password);
                outPutFile.WriteLine(_race);
                outPutFile.WriteLine(_classType);
                Console.WriteLine("Profile Saved");
                outPutFile.Close();
            }
            catch
            {
                Console.WriteLine("ERROR SAVING PROFILE");
            }
            

            
        }
    }
}
