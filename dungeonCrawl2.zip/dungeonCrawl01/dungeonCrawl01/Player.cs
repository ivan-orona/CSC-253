﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    class Player
    {
        public string Name { get; set; }
        public string Password { get; set; }
        public string Race { get; set; }
        public string ClassType { get; set; }
        public Player(string name, string password, string race, string classType)
        {
            Name = name;
            Password = password;
            Race = race;
            ClassType = classType; 
        }

       
    }
}
