﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class Weapons
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public int Damage { get; set; }

        public Weapons(string name, string type, int damage)
        {
            Name = name;
            Type = type;
            Damage = damage;
        }
    }
}
