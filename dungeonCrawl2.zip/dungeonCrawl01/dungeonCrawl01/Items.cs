﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class Items
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public int Health { get; set; }

        public Items(string name, string type, int health)
        {
            Name = name;
            Type = type;
            Health = health;
        }
    }
}
