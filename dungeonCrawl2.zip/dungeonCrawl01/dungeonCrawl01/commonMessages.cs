﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    public class commonMessages
    {
        public static void welcomeMSG()
        {
            Console.WriteLine("Your adventure has begun");
        }
        public static void newGamePrompt()
        {
            Console.WriteLine("\nNew game press [N] \nLoad game press [L]");
        }
        public static void newNamePrompt()
        {
            Console.WriteLine("Please enter your name: ");
        }
        public static void newPasswordPrompt()
        {
            Console.WriteLine("Please enter your password: ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("MUST INCLUDE 1 CAPITAL LETTER 1 LOWERCASE LETTER \n1 SPECIAL CHARACTER AND BE 8 CHARACTERS LONG");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public static void newClassPrompt()
        {
            Console.WriteLine("Select your class: Warrior [W] Mage [M] Thief [T] Cleric [C]");
        }
        public static void newRacePrompt()
        {
            Console.WriteLine("Select your race: Elf [E] Human [H] Dwarf [D]");
        }

    }
}
