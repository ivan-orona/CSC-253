﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
    class gameStatus
    {
        public static void gameState(int index)
        {
            Console.WriteLine("\nYou are currently in: " + Program.map[index]);
            Console.WriteLine("your commands are N for north, S for South and E for exit and L for lookup");
            try
            {
                string userInput;
                userInput = Console.ReadLine().ToLower();

                //If user wants to move North, we add + 1 to the global variable thats holds the current index of the array, then calls gamState()
                if (userInput == "n")
                {
                    if (Program.globalINT < 4)
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Program.globalINT = Program.globalINT + 1;
                        gameState(Program.globalINT);


                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine("There is no way out North");
                        gameState(Program.globalINT);

                    }
                }
                //If user wants to move south, we subtract - 1 to the global variable that holds the current index of the array, then calls gamState().
                if (userInput == "s")
                {
                    if (Program.globalINT > 0)
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Program.globalINT = Program.globalINT - 1;
                        gameState(Program.globalINT);

                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine("There is no way out South");
                        gameState(Program.globalINT);
                    }
                }
                //Used for exiting application
                if (userInput == "e")
                {
                    Console.WriteLine("Good Bye");
                    Environment.Exit(0);
                }
                if (userInput == "l")
                {
                    Weapons[] dummyArray = generateArrays.LoadWeaponsObj();
                    string userChoice;
                    Console.WriteLine("Available Items to lookup:(Slect by entering corresponding number) \n1.Sword\n2.Bow\n3.Mace\n4.Axe");
                    userChoice = Console.ReadLine();
                    if (userChoice == "1")
                    {
                        Console.WriteLine("Name: "+ dummyArray[0].Name + "\nAttack type: "+ dummyArray[0].Type + "\nDamage: " + dummyArray[0].Damage);
                        gameState(Program.globalINT);
                    }
                    else if (userChoice == "2")
                    {
                        Console.WriteLine("Name: " + dummyArray[1].Name + "\nAttack type: " + dummyArray[1].Type + "\nDamage: " + dummyArray[1].Damage);
                        gameState(Program.globalINT);
                    }
                    else if (userChoice == "3")
                    {
                        Console.WriteLine("Name: " + dummyArray[2].Name + "\nAttack type: " + dummyArray[2].Type + "\nDamage: " + dummyArray[2].Damage);
                        gameState(Program.globalINT);
                    }
                    else if (userChoice == "4")
                    {
                        Console.WriteLine("Name: " + dummyArray[3].Name + "\nAttack type: " + dummyArray[3].Type + "\nDamage: " + dummyArray[3].Damage);
                        gameState(Program.globalINT);
                    }
                    else
                    {
                        Console.WriteLine("Incorrect choice");
                        gameState(Program.globalINT);
                    }
                }
            }
            //Catch any error and will display message.
            catch
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Incorrect input! Your commands are N for North S for South and E for exit");
                gameState(Program.globalINT);
            }
        }
    }
}
