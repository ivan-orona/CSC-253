﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dungeonCrawl01
{
   public class Mobs
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public int Damage { get; set; }

        public Mobs(string name, string type, int damage)
        {
            Name = name;
            Type = type;
            Damage = damage;
        }
    }
}
