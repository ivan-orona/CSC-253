﻿/**
* 10/8/2018
* CSC 253
* Miguel Ivan Orona
* This program will prompt the user to enter a sentence and the program
* will accept the input and place the string into an array to be accepted
* into a method arguement and output the count of words in the sentence.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Accepting the array as as an arguement for the ShowCount method.
        private void ShowCount(string[] tokens)
        {
            int count = 0;  //Initializes the count variable.
            foreach (string str in tokens)  //For each string in the array, it will be counted.
            {
                count += 1;
            }
            //Displays the count of strings to the output box.
            outputTextBox.Text = count.ToString();
        }
        private void countButton_Click(object sender, EventArgs e)
        {
            try
            {
                string userString = inputTextBox.Text;  //Accepts user input into a variable.
                string[] tokens = userString.Split(null);   //Splits & tokenizes the string into an array.
                ShowCount(tokens);  //Calls the ShowCount method.
            }
            catch
            {
                //throws an error message
                MessageBox.Show("Error!");
            } 
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears the boxes
            inputTextBox.Clear();
            outputTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }
    }
}//End program
