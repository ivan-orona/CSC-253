﻿/**
* August 27, 2018
* CSC 253
* Miguel Ivan Orona
* This program will prompt the user to input a number 
* of books purchased and calculate how many points the
* user has earned based on the user input. The program
* will then display the output.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW1_OronaMiguel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int number; //Hold the integer as variable.
            string input = inputTextBox.Text;   //Holds the user's input into a variable.

            if (int.TryParse(input, out number))
            {
                switch (number)
                {
                    case 0:
                        outputTextBox.Text = "O Points";
                        break;
                    case 1:
                        outputTextBox.Text = "5 Points";
                        break;
                    case 2:
                        outputTextBox.Text = "15 Points";
                        break;
                    case 3:
                        outputTextBox.Text = "30 Points";
                        break;
                    default:    //For any input integer greater than 3, 60 points is the cap.
                        outputTextBox.Text = "60 Points";
                        break;
                }
            }
            else
            {
                //The error message will catch anything that is not a valid integer.
                outputTextBox.Text = ("That's not a valid integer!");
            }

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            inputTextBox.Clear();   //Clears input box.
            outputTextBox.Clear();  //Clears output box.
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the form.
            this.Close();
        }
    }
}
//End program.