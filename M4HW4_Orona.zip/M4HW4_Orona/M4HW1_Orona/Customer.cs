﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M4HW1_Orona
{
    class Customer : Person //Extends the person class
    {
        private int _customNumber;
        private bool _mailList;

        public Customer(String name, String address, double phoneNumber,/*new*/ int customerNumber, bool mailList) : base(name, address, phoneNumber)
        {
            _customNumber = customerNumber;
            _mailList = mailList;
        }
        public Customer() { _customNumber = 0; _mailList = false; }
        public void setCustomerNumber(int customerNum) { _customNumber = customerNum; }
        public void setMailList(bool mailList) { _mailList = mailList; }
        public int getCustomerNumber() { return _customNumber; }
        public bool getMailList() { return _mailList; }
        public string checkMail()
        {
            if (_mailList == true)
            {
                string str2 = ("Customer Number: "+_customNumber+" - Email: confirmed");
                return str2;
            }
            else if (_mailList == false)
            {
                string str2 = ("Customer Number: "+_customNumber+" - Email: DECLINED") ;
                return str2;
            }
            else
            {
                string str2 = ("INVALID ENTRY");
                return str2;
            }
        }
    }
}
   

