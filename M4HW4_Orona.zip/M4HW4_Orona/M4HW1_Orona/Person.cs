﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M4HW1_Orona
{
    class Person
    {
        private string _name;
        private string _address;
        private double _phoneNumber;
        public Person(String name, String address, double phoneNumber)
        {
            _name = name;
            _address = address;
            _phoneNumber = phoneNumber;
        }
        public Person() { _name = ""; _address = ""; _phoneNumber = 0; }
        public void setName(string name) { _name = name; }
        public void setAddress(string address) { _address = address; }
        public void setPhoneNumber(double phoneNumber) { _phoneNumber = phoneNumber; }
        public string getName() { return _name; }
        public string getAddress() { return _address; }
        public double getPhoneNumber() { return _phoneNumber; }

        public string checkPerson()
        {
            string outputItems = ("Name: " + _name + " - address: " + _address + " - Phone Number: " + _phoneNumber);
            return outputItems;
        }
    }
}
