﻿/**
/**
* 11/8/2018
* CSC 253
* Miguel Ivan Orona
* This program will utilize user input to create a person class
* and a customer child class placing userInput into objects and
* also checking user input to validate mailing list confirmation.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW1_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            string userName = nameInputTextBox.Text;  //Holds the users name
            string address = addressInputTextBox.Text; //user address
            double phoneNumber = double.Parse(phoneInputTextBox.Text);   //user phone number.
            int customerNumber = int.Parse(customerNumberTextBox.Text); //Customer id number
            string userMailList = ((mailInputTextBox.Text).ToLower()); //yes means confirmed, no means declined.
            bool mailList = false;  //Initializer

            if (userMailList == "y") { mailList = true; }   //If user input is y(es), boolean becomes true.
            else if (userMailList == "n") { mailList = false; } //If user input is n(o), boolean remains false.
            else { MessageBox.Show("That is not a valid answer. Type either (y or n) "); }  //Invalid input throws error.

            

            Person person = new Person(userName, address, phoneNumber); //Creates the person object with user input.
            Customer customer = new Customer(userName, address, phoneNumber,customerNumber, mailList);  //Extends the class with two more parameters

            //Outputs the information to textboxes.
            personOutputTextBox.Text = (person.checkPerson());
            customerOutputTextBox.Text = (customer.checkMail());
        }

        private void restartButton_Click(object sender, EventArgs e)
        {
            //Clears all text boxes
            nameInputTextBox.Clear();
            addressInputTextBox.Clear();
            phoneInputTextBox.Clear();
            mailInputTextBox.Clear();
            customerNumberTextBox.Clear();
            personOutputTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }
    }
}
//End of program.