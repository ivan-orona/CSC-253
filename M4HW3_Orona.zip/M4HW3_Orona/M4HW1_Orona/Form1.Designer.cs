﻿namespace M4HW1_Orona
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.firstNameInputBox = new System.Windows.Forms.TextBox();
            this.empNumTextBox = new System.Windows.Forms.TextBox();
            this.shiftTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.payRateTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.restartButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.nameNumberOuputTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.inputProductionTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.inputSalaryTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.supervisorOutputTextBox = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.teamLeaderBonusBox = new System.Windows.Forms.TextBox();
            this.teamLeaderHourInBox = new System.Windows.Forms.TextBox();
            this.teamLeaderHourReqBox = new System.Windows.Forms.TextBox();
            this.teamLeaderOuputTextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Employee Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(62, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Employee Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Shift Number 1-2:";
            // 
            // firstNameInputBox
            // 
            this.firstNameInputBox.Location = new System.Drawing.Point(164, 59);
            this.firstNameInputBox.Name = "firstNameInputBox";
            this.firstNameInputBox.Size = new System.Drawing.Size(124, 20);
            this.firstNameInputBox.TabIndex = 6;
            // 
            // empNumTextBox
            // 
            this.empNumTextBox.Location = new System.Drawing.Point(164, 94);
            this.empNumTextBox.Name = "empNumTextBox";
            this.empNumTextBox.Size = new System.Drawing.Size(124, 20);
            this.empNumTextBox.TabIndex = 7;
            // 
            // shiftTextBox
            // 
            this.shiftTextBox.Location = new System.Drawing.Point(164, 139);
            this.shiftTextBox.Name = "shiftTextBox";
            this.shiftTextBox.Size = new System.Drawing.Size(124, 20);
            this.shiftTextBox.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(139, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "EMPLOYEES";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(71, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Hourly Pay Rate:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.payRateTextBox);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.shiftTextBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.firstNameInputBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.empNumTextBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(23, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(307, 261);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 194);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(151, 13);
            this.label11.TabIndex = 31;
            this.label11.Text = "(Supervisors please enter \'NA\')";
            // 
            // payRateTextBox
            // 
            this.payRateTextBox.Location = new System.Drawing.Point(164, 178);
            this.payRateTextBox.Name = "payRateTextBox";
            this.payRateTextBox.Size = new System.Drawing.Size(124, 20);
            this.payRateTextBox.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 159);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(151, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "(Supervisors please enter \'NA\')";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(401, 322);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(112, 35);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // restartButton
            // 
            this.restartButton.Location = new System.Drawing.Point(283, 322);
            this.restartButton.Name = "restartButton";
            this.restartButton.Size = new System.Drawing.Size(112, 35);
            this.restartButton.TabIndex = 0;
            this.restartButton.Text = "Restart";
            this.restartButton.UseVisualStyleBackColor = true;
            this.restartButton.Click += new System.EventHandler(this.restartButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(165, 322);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(112, 35);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "Employee";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // nameNumberOuputTextBox
            // 
            this.nameNumberOuputTextBox.Location = new System.Drawing.Point(24, 397);
            this.nameNumberOuputTextBox.Name = "nameNumberOuputTextBox";
            this.nameNumberOuputTextBox.Size = new System.Drawing.Size(636, 20);
            this.nameNumberOuputTextBox.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(303, 381);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Employee Info:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.inputProductionTextBox);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.inputSalaryTextBox);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(352, 64);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(307, 117);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Shift Supervisor";
            // 
            // inputProductionTextBox
            // 
            this.inputProductionTextBox.Location = new System.Drawing.Point(162, 60);
            this.inputProductionTextBox.Name = "inputProductionTextBox";
            this.inputProductionTextBox.Size = new System.Drawing.Size(100, 20);
            this.inputProductionTextBox.TabIndex = 29;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 13);
            this.label6.TabIndex = 28;
            this.label6.Text = "Annual Production Bonus:";
            // 
            // inputSalaryTextBox
            // 
            this.inputSalaryTextBox.Location = new System.Drawing.Point(162, 26);
            this.inputSalaryTextBox.Name = "inputSalaryTextBox";
            this.inputSalaryTextBox.Size = new System.Drawing.Size(100, 20);
            this.inputSalaryTextBox.TabIndex = 24;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(70, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 13);
            this.label8.TabIndex = 27;
            this.label8.Text = "Annual Salary:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(303, 437);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "Supervisor Info:";
            // 
            // supervisorOutputTextBox
            // 
            this.supervisorOutputTextBox.Location = new System.Drawing.Point(24, 453);
            this.supervisorOutputTextBox.Name = "supervisorOutputTextBox";
            this.supervisorOutputTextBox.Size = new System.Drawing.Size(636, 20);
            this.supervisorOutputTextBox.TabIndex = 29;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.teamLeaderBonusBox);
            this.groupBox3.Controls.Add(this.teamLeaderHourInBox);
            this.groupBox3.Controls.Add(this.teamLeaderHourReqBox);
            this.groupBox3.Location = new System.Drawing.Point(352, 187);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(307, 129);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Team Leader";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(48, 84);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 13);
            this.label12.TabIndex = 31;
            this.label12.Text = "Monthly Bonus:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(41, 58);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 13);
            this.label13.TabIndex = 32;
            this.label13.Text = "Hours Recorded:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(48, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 13);
            this.label14.TabIndex = 33;
            this.label14.Text = "Hours Required:";
            // 
            // teamLeaderBonusBox
            // 
            this.teamLeaderBonusBox.Location = new System.Drawing.Point(184, 84);
            this.teamLeaderBonusBox.Name = "teamLeaderBonusBox";
            this.teamLeaderBonusBox.Size = new System.Drawing.Size(100, 20);
            this.teamLeaderBonusBox.TabIndex = 33;
            // 
            // teamLeaderHourInBox
            // 
            this.teamLeaderHourInBox.Location = new System.Drawing.Point(184, 58);
            this.teamLeaderHourInBox.Name = "teamLeaderHourInBox";
            this.teamLeaderHourInBox.Size = new System.Drawing.Size(100, 20);
            this.teamLeaderHourInBox.TabIndex = 31;
            // 
            // teamLeaderHourReqBox
            // 
            this.teamLeaderHourReqBox.Location = new System.Drawing.Point(184, 26);
            this.teamLeaderHourReqBox.Name = "teamLeaderHourReqBox";
            this.teamLeaderHourReqBox.Size = new System.Drawing.Size(100, 20);
            this.teamLeaderHourReqBox.TabIndex = 32;
            // 
            // teamLeaderOuputTextBox
            // 
            this.teamLeaderOuputTextBox.Location = new System.Drawing.Point(24, 504);
            this.teamLeaderOuputTextBox.Name = "teamLeaderOuputTextBox";
            this.teamLeaderOuputTextBox.Size = new System.Drawing.Size(636, 20);
            this.teamLeaderOuputTextBox.TabIndex = 31;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(303, 488);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(94, 13);
            this.label15.TabIndex = 32;
            this.label15.Text = "Team Leader Info:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(208, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(252, 13);
            this.label16.TabIndex = 33;
            this.label16.Text = "PLEASE ENSURE ALL TEXT BOXES ARE FILLED";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 541);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.teamLeaderOuputTextBox);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.supervisorOutputTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.nameNumberOuputTextBox);
            this.Controls.Add(this.restartButton);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Employee and Production";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox firstNameInputBox;
        private System.Windows.Forms.TextBox empNumTextBox;
        private System.Windows.Forms.TextBox shiftTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button restartButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.TextBox payRateTextBox;
        private System.Windows.Forms.TextBox nameNumberOuputTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox inputSalaryTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox supervisorOutputTextBox;
        private System.Windows.Forms.TextBox inputProductionTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox teamLeaderBonusBox;
        private System.Windows.Forms.TextBox teamLeaderHourInBox;
        private System.Windows.Forms.TextBox teamLeaderHourReqBox;
        private System.Windows.Forms.TextBox teamLeaderOuputTextBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
    }
}

