﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M4HW1_Orona
{
    class TeamLeader : Employee //Extends the employee class
    {
        int _monthlyBonus;  
        int _hoursIn;
        int _hoursReq;
        //Constructor
        public TeamLeader(string name, string employeeNumber, int monthlyBonus,
            int hoursIn, int hoursReq):base(name, employeeNumber)
        {
            _monthlyBonus = monthlyBonus;
            _hoursIn = hoursIn;
            _hoursReq = hoursReq;
        }
        public TeamLeader()
        {   //Initalize
            _monthlyBonus = 0;
            _hoursIn = 0;
            _hoursReq = 0;
        }
        //Getters and setters.
        public void setMonthlyBonus(int monthlyBonus){ _monthlyBonus = monthlyBonus; }
        public void setHoursIn(int hoursIn) { _hoursIn = hoursIn; }
        public void setHoursReq(int hoursReq) { _hoursReq = hoursReq; }
        public int getMonthlyBonus() { return _monthlyBonus; }
        public int getHoursIn() { return _hoursIn; }
        public int getHoursReq() { return _hoursReq; }

        //Method to check if bonus is allowed and time met. 
        public string TeamLeaderCheck()
        {
            string str = "Hours required: " + _hoursIn + "Hours completed: " + _hoursReq;

            if (_hoursIn >= _hoursReq)
            {
                string str2 = "The required hours have been met. Bonus of: " + _monthlyBonus+ " allotted.";
                return str + str2;
            }
            else if (_hoursIn <= _hoursReq)
            {
                string str2 = "The required hours have NOT been met. Bonus withheld.";
                return str + str2;
            }
            else
            {
                //Will throw an error if the hour check is invalid.
                String str2 = "Error. Please try again!";
                return str + str2;
            }
        }

    }
}
