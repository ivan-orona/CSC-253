﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M4HW1_Orona
{
    //Extending the Employee class with the ProductionWorker class to add information.
    class ProductionWorker : Employee
    {
        private int shift;  //Holds the employees shift.
        private double payRate; //Holds the employees pay rate. 

        //Extends the information.
        public ProductionWorker(string name, string employeeNumber, /*new*/int sh, double rate):base(name, employeeNumber)
        {
            shift = sh;
            payRate = rate;
        }
        
        public ProductionWorker()
        {
            shift = 0;
            payRate = 0;
        }
        public void setShift(int s)
        {
            shift = s;
        }
        public void setPayRate(double p)
        {
            payRate = p;
        }
        public int getShift()
        {
            return shift;
        }
        public double getPayRate()
        {
            return payRate;
        }
        public string ShiftCheck()
        {
            //This statement will ensure that the shift entered corresponds with 1 or 2. 
            //Any deviation (i.e 3 or 4 or 0 or even a string) will throw an error.
            if (shift == 1)
            {
                string str = " Shift Number: " + shift + " Hourly Pay: $" + payRate;
                return str;
            }
            else if (shift == 2)
            {
                string str = " Shift Number: " + shift + " Hourly Pay: $" + payRate;
                return str;
            }
            else
            {
                string str = " Shift Number: That is not a valid shift!" + " Hourly pay: " + payRate;
                return str;
            }
        }
    }
}
