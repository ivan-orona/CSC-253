﻿/**
* September 4, 2018
* CSC 253
* Miguel Ivan Orona
* This program will prompt the user to enter the mass and velocity of 
* a given object and retun the kinetic energy output after processesing the 
* input and performang the formula steps.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW3_Orona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double objectMass;      //Holds constant variable for mass.
        double objectVelocity;  //Holds constant variable for velocity.

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //parses the input to a double   
            objectMass = double.Parse(massInputBox.Text);   
            objectVelocity = double.Parse(velocityInputBox.Text);

            //Calls the getKineticEnergy method and passes the mass & velocity 
            double result = getKineticEnergy(objectMass, objectVelocity);

            //Displays the result that was returned from the getKineticEnergy method.
            outputTextBox.Text = (result.ToString()); 
        }

            static double getKineticEnergy(double objectMass, double objectVelocity)
        {
            //The math equation for Kinetic energy: KE = 1/2(MV)2
            double finalAnsw =0.5 * (objectMass * Math.Pow(objectVelocity, 2));
            return finalAnsw;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears all text boxes to allow re-entry.
            massInputBox.Clear();
            velocityInputBox.Clear();
            outputTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program.
            this.Close();
        }
    }
    
}
//End Program.
